public class Main {

    public static void main(String[] args) {

        // MISIÓN 1: ÁRBOL DE YGGDRASIL
        System.out.println("\n-------MISIÓN 1: YGGDRASIL--------");
        ArbolBinario yggdrasil = new ArbolBinario();
        yggdrasil.crearYggdrasil();

        System.out.println("Raíz: " + yggdrasil.raiz.nombre);
        System.out.println("Hijo izquierdo: " + yggdrasil.raiz.izquierdo.nombre);
        System.out.println("Hijo derecho: " + yggdrasil.raiz.derecho.nombre);

        // Las misiones 2 a 10 utilizan un árbol BST numérico independiente.
        ArbolBinario arbol = new ArbolBinario();

        // MISIÓN 2: INSERTAR
        System.out.println("\n---------------MISIÓN 2: INSERTAR------------");
        int[] valores = {50, 40, 60, 20, 30, 80, 70, 10, 90};
        for (int valor : valores) {
            arbol.insertar(valor);
        }
        System.out.println(" Los Nueve nodos fueron insertados correctamente.");

        // MISIÓN 3: BUSCAR
        System.out.println("\n--------- MISIÓN 3: BUSCAR --------");
        System.out.println("¿Existe 60? " + arbol.buscar(60));
        System.out.println("¿Existe 100? " + arbol.buscar(100));

        // MISIÓN 4: INORDEN
        System.out.println("\n--------- MISIÓN 4: INORDEN --------");
        System.out.print("Recorrido: ");
        arbol.inOrden();
        System.out.println();

        // MISIÓN 5: PREORDEN
        System.out.println("\n ------- MISIÓN 5: PREORDEN -------");
        System.out.print("Recorrido: ");
        arbol.preOrden();
        System.out.println();

        // MISIÓN 6: POSTORDEN
        System.out.println("\n------ MISIÓN 6: POSTORDEN ------");
        System.out.print("Recorrido: ");
        arbol.postOrden();
        System.out.println();

        // Se vacía un árbol auxiliar para poder continuar las demás misiones.
        ArbolBinario arbolParaVaciar = new ArbolBinario();
        for (int valor : valores) {
            arbolParaVaciar.insertar(valor);
        }
        arbolParaVaciar.vaciar();
        System.out.println("Nodos del árbol auxiliar tras vaciar en postorden: "
                + arbolParaVaciar.contarLineas());

        // MISIÓN 7: CONTAR NODOS
        System.out.println("\n------- MISIÓN 7: CONTAR NODOS -------");
        System.out.println("Cantidad total de nodos: " + arbol.contarLineas());

        // MISIÓN 8: MENOR Y MAYOR
        System.out.println("\n--------MISIÓN 8: MENOR Y MAYOR -------");
        System.out.println("Valor menor: " + arbol.encontrarMenor());
        System.out.println("Valor mayor: " + arbol.encontrarMayor());

        // MISIÓN 9: ALTURA
        System.out.println("\n------ MISIÓN 9: ALTURA ------");
        System.out.println("Altura del árbol (en aristas): " + arbol.calcularAltura());

        // MISIÓN 10: ELIMINAR EN SUS TRES CASOS
        System.out.println("\n------- MISIÓN 10: ELIMINAR -------");
        System.out.print("Árbol inicial: ");
        arbol.inOrden();
        System.out.println();

        // Caso 1: eliminar hoja (10)
        System.out.println("\n eliminar nodo hoja (10)");
        arbol.eliminar(10);
        System.out.print("Resultado: ");
        arbol.inOrden();
        System.out.println();

        // Caso 2: eliminar nodo con un hijo (20, cuyo hijo es 30)
        System.out.println("\n eliminar nodo con un hijo (20)");
        arbol.eliminar(20);
        System.out.print("Resultado: ");
        arbol.inOrden();
        System.out.println();

        // Caso 3: eliminar nodo con dos hijos (50)
        System.out.println("\n eliminar nodo con dos hijos (50)");
        arbol.eliminar(50);
        System.out.print("Resultado: ");
        arbol.inOrden();
        System.out.println();

        System.out.println("\n------ LAS 10 MISIONES FINALIZARON -------");
    }
}
