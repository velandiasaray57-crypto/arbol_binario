import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class PruebasArbolBinario {

    private static int comprobaciones;
    private static int fallos;

    public static void main(String[] args) throws Exception {
        probarArbolVacio();
        probarYggdrasil();
        probarOperacionesBasicas();
        probarVaciadoPostOrden();
        probarEliminacion();
        probarSucesores();
        probarLimitesYArbolesLineales();

        System.out.println("Comprobaciones: " + comprobaciones + "; fallos: " + fallos);
        if (fallos != 0) {
            throw new AssertionError("Hay comprobaciones que no se cumplen.");
        }
        System.out.println("Todas las pruebas pasaron.");
    }

    private static void comprobar(boolean condicion, String descripcion) {
        comprobaciones++;
        if (!condicion) {
            fallos++;
            System.out.println("FALLO: " + descripcion);
        }
    }

    private static ArbolBinario crear(int... valores) {
        ArbolBinario arbol = new ArbolBinario();
        for (int valor : valores) {
            arbol.insertar(valor);
        }
        return arbol;
    }

    private static String recorrido(ArbolBinario arbol, int tipo) throws Exception {
        PrintStream salidaOriginal = System.out;
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        PrintStream captura = new PrintStream(buffer, true, "UTF-8");
        try {
            System.setOut(captura);
            if (tipo == 0) {
                arbol.inOrden();
            } else if (tipo == 1) {
                arbol.preOrden();
            } else {
                arbol.postOrden();
            }
        } finally {
            System.setOut(salidaOriginal);
            captura.close();
        }
        return buffer.toString("UTF-8").trim();
    }

    private static void probarArbolVacio() throws Exception {
        ArbolBinario arbol = new ArbolBinario();
        comprobar(arbol.raiz == null, "raiz inicialmente nula");
        comprobar(!arbol.buscar(7), "buscar en arbol vacio");
        comprobar(arbol.contarLineas() == 0, "cantidad de nodos vacios");
        comprobar(arbol.calcularAltura() == -1, "altura del arbol vacio: -1");
        for (int tipo = 0; tipo < 3; tipo++) {
            comprobar(recorrido(arbol, tipo).equals(""), "recorrido vacio " + tipo);
        }
        boolean menorRechazado = false;
        try {
            arbol.encontrarMenor();
        } catch (IllegalStateException esperado) {
            menorRechazado = true;
        }
        comprobar(menorRechazado, "menor en arbol vacio informa error");
        boolean mayorRechazado = false;
        try {
            arbol.encontrarMayor();
        } catch (IllegalStateException esperado) {
            mayorRechazado = true;
        }
        comprobar(mayorRechazado, "mayor en arbol vacio informa error");
        arbol.eliminar(7);
        comprobar(arbol.raiz == null, "eliminar de un arbol vacio");
    }

    private static void probarYggdrasil() {
        ArbolBinario arbol = new ArbolBinario();
        arbol.crearYggdrasil();
        comprobar(arbol.raiz.nombre.equals("Asgard"), "raiz Asgard");
        comprobar(arbol.raiz.izquierdo.nombre.equals("Midgard"), "Midgard a la izquierda");
        comprobar(arbol.raiz.derecho.nombre.equals("Vanaheim"), "Vanaheim a la derecha");
        comprobar(arbol.contarLineas() == 3, "tres reinos enlazados");
        comprobar(arbol.calcularAltura() == 1, "altura de Yggdrasil: 1");
        comprobar(esBST(arbol.raiz, Long.MIN_VALUE, Long.MAX_VALUE), "Yggdrasil respeta el BST numerico");
    }

    private static void probarOperacionesBasicas() throws Exception {
        ArbolBinario arbol = crear(50, 40, 60, 20, 30, 80, 70, 10, 90);
        comprobar(arbol.contarLineas() == 9, "nueve inserciones");
        comprobar(arbol.raiz.valor == 50, "primera insercion crea la raiz");
        comprobar(arbol.raiz.izquierdo.valor == 40, "insercion izquierda");
        comprobar(arbol.raiz.derecho.valor == 60, "insercion derecha");
        comprobar(arbol.buscar(60) && arbol.buscar(10) && arbol.buscar(90), "buscar valores presentes");
        comprobar(!arbol.buscar(100) && !arbol.buscar(45), "buscar valores ausentes");
        comprobar(arbol.encontrarMenor() == 10, "menor: 10");
        comprobar(arbol.encontrarMayor() == 90, "mayor: 90");
        comprobar(arbol.calcularAltura() == 3, "altura del ejemplo: 3 aristas");
        comprobar(recorrido(arbol, 0).equals("10 20 30 40 50 60 70 80 90"), "inorden exacto");
        comprobar(recorrido(arbol, 1).equals("50 40 20 10 30 60 80 70 90"), "preorden exacto");
        comprobar(recorrido(arbol, 2).equals("10 30 20 40 70 90 80 60 50"), "postorden exacto");
        comprobar(arbol.contarLineas() == 9 && arbol.buscar(50), "los recorridos conservan el arbol");
        arbol.insertar(50);
        arbol.insertar(20);
        comprobar(arbol.contarLineas() == 9, "se ignoran duplicados");
        arbol.eliminar(999);
        comprobar(recorrido(arbol, 0).equals("10 20 30 40 50 60 70 80 90"), "eliminar ausente conserva el arbol");
    }

    private static void probarVaciadoPostOrden() throws Exception {
        ArbolBinario arbol = crear(50, 30, 70, 20, 40, 60, 80);
        NodoVengador raizAnterior = arbol.raiz;
        NodoVengador izquierdaAnterior = arbol.raiz.izquierdo;
        NodoVengador derechaAnterior = arbol.raiz.derecho;
        arbol.vaciar();
        comprobar(arbol.raiz == null, "vaciado postorden: raiz nula");
        comprobar(arbol.contarLineas() == 0, "vaciado postorden: sin nodos");
        comprobar(raizAnterior.izquierdo == null && raizAnterior.derecho == null,
                "vaciado postorden: desconectar enlaces de la raiz");
        comprobar(izquierdaAnterior.izquierdo == null && izquierdaAnterior.derecho == null,
                "vaciado postorden: desconectar subarbol izquierdo");
        comprobar(derechaAnterior.izquierdo == null && derechaAnterior.derecho == null,
                "vaciado postorden: desconectar subarbol derecho");
        comprobar(recorrido(arbol, 2).equals(""), "postorden despues de vaciar");
        arbol.vaciar();
        comprobar(arbol.raiz == null, "vaciar de nuevo es seguro");
        arbol.insertar(42);
        comprobar(arbol.buscar(42) && arbol.contarLineas() == 1, "insertar tras vaciar en postorden");
    }

    private static void probarEliminacion() throws Exception {
        ArbolBinario arbol = crear(50, 40, 60, 20, 30, 80, 70, 10, 90);
        arbol.eliminar(10);
        comprobar(!arbol.buscar(10) && arbol.contarLineas() == 8, "eliminar hoja");
        comprobar(arbol.raiz.izquierdo.izquierdo.izquierdo == null, "desenlazar hoja");
        arbol.eliminar(20);
        comprobar(arbol.raiz.izquierdo.izquierdo.valor == 30, "reconectar hijo derecho de nodo interno");
        comprobar(!arbol.buscar(20) && arbol.contarLineas() == 7, "eliminar nodo con un hijo");
        arbol.eliminar(50);
        comprobar(arbol.raiz.valor == 60, "reemplazar raiz por sucesor directo");
        comprobar(recorrido(arbol, 0).equals("30 40 60 70 80 90"), "dos hijos: inorden final");
        comprobar(arbol.contarLineas() == 6 && !arbol.buscar(50), "dos hijos: quitar solo un nodo");

        ArbolBinario hoja = crear(5);
        comprobar(hoja.calcularAltura() == 0, "altura de una hoja: 0");
        comprobar(hoja.encontrarMenor() == 5 && hoja.encontrarMayor() == 5, "extremos de un unico nodo");
        hoja.eliminar(5);
        comprobar(hoja.raiz == null && hoja.contarLineas() == 0, "eliminar raiz hoja");

        ArbolBinario hijoIzquierdo = crear(5, 3);
        NodoVengador izquierda = hijoIzquierdo.raiz.izquierdo;
        hijoIzquierdo.eliminar(5);
        comprobar(hijoIzquierdo.raiz == izquierda, "promover referencia al hijo izquierdo");

        ArbolBinario hijoDerecho = crear(5, 7);
        NodoVengador derecha = hijoDerecho.raiz.derecho;
        hijoDerecho.eliminar(5);
        comprobar(hijoDerecho.raiz == derecha, "promover referencia al hijo derecho");

        ArbolBinario interno = crear(50, 30, 20, 10);
        interno.eliminar(20);
        comprobar(interno.raiz.izquierdo.izquierdo.valor == 10, "reconectar hijo izquierdo de nodo interno");
    }

    private static void probarSucesores() throws Exception {
        ArbolBinario arbol = crear(50, 30, 80, 60, 90, 55, 57);
        arbol.raiz.derecho.izquierdo.izquierdo.nombre = "Sucesor";
        arbol.eliminar(50);
        comprobar(arbol.raiz.valor == 55, "sucesor profundo");
        comprobar(arbol.raiz.nombre.equals("Sucesor"), "copiar tambien el nombre del sucesor");
        comprobar(arbol.raiz.derecho.izquierdo.izquierdo.valor == 57, "conservar hijo derecho del sucesor");
        comprobar(arbol.contarLineas() == 6, "sin duplicar el sucesor");
        comprobar(recorrido(arbol, 0).equals("30 55 57 60 80 90"), "inorden tras sucesor profundo");
        comprobar(esBST(arbol.raiz, Long.MIN_VALUE, Long.MAX_VALUE), "orden BST tras sucesor profundo");

        ArbolBinario interno = crear(50, 30, 70, 20, 40, 35, 45);
        interno.eliminar(30);
        comprobar(interno.raiz.izquierdo.valor == 35, "eliminar nodo interno con dos hijos");
        comprobar(recorrido(interno, 0).equals("20 35 40 45 50 70"), "inorden tras eliminar interno");
    }

    private static void probarLimitesYArbolesLineales() throws Exception {
        ArbolBinario limites = crear(0, Integer.MIN_VALUE, Integer.MAX_VALUE, -1, 1);
        comprobar(limites.encontrarMenor() == Integer.MIN_VALUE, "menor int posible");
        comprobar(limites.encontrarMayor() == Integer.MAX_VALUE, "mayor int posible");
        comprobar(limites.buscar(-1), "buscar negativos");
        limites.eliminar(0);
        comprobar(esBST(limites.raiz, Long.MIN_VALUE, Long.MAX_VALUE), "eliminar con valores extremos");

        ArbolBinario ascendente = crear(1, 2, 3, 4, 5);
        ArbolBinario descendente = crear(5, 4, 3, 2, 1);
        comprobar(ascendente.calcularAltura() == 4, "altura de cadena derecha: 4");
        comprobar(descendente.calcularAltura() == 4, "altura de cadena izquierda: 4");
        comprobar(ascendente.buscar(5) && descendente.buscar(1), "buscar al final de cadenas");
        for (int valor = 1; valor <= 5; valor++) {
            ascendente.eliminar(valor);
            comprobar(ascendente.contarLineas() == 5 - valor, "vaciado sucesivo: cantidad " + valor);
            comprobar(!ascendente.buscar(valor), "vaciado sucesivo: ausencia " + valor);
            comprobar(esBST(ascendente.raiz, Long.MIN_VALUE, Long.MAX_VALUE), "vaciado sucesivo: orden " + valor);
        }
        comprobar(ascendente.raiz == null, "vaciado completo");
        ascendente.insertar(42);
        comprobar(recorrido(ascendente, 0).equals("42"), "reinsertar despues de vaciar");
    }

    private static boolean esBST(NodoVengador nodo, long minimo, long maximo) {
        if (nodo == null) {
            return true;
        }
        return nodo.valor > minimo && nodo.valor < maximo
                && esBST(nodo.izquierdo, minimo, nodo.valor)
                && esBST(nodo.derecho, nodo.valor, maximo);
    }
}
