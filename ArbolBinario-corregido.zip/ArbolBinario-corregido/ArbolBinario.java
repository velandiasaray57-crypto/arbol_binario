public class ArbolBinario {

    NodoVengador raiz;

    // MISIÓN 1: EL ÁRBOL DE YGGDRASIL
    public void crearYggdrasil() {
        raiz = new NodoVengador(50, "Asgard");
        raiz.izquierdo = new NodoVengador(25, "Midgard");
        raiz.derecho = new NodoVengador(75, "Vanaheim");
    }

    // MISIÓN 2: INSERTAR NODOS EN UN ÁRBOL BST
    public void insertar(int nivelSeguridad) {
        raiz = insertarRecursivo(raiz, nivelSeguridad);
    }

    private NodoVengador insertarRecursivo(NodoVengador actual, int valor) {
        if (actual == null) {
            return new NodoVengador(valor);
        }

        if (valor < actual.valor) {
            actual.izquierdo = insertarRecursivo(actual.izquierdo, valor);
        } else if (valor > actual.valor) {
            actual.derecho = insertarRecursivo(actual.derecho, valor);
        }

        return actual;
    }

    // MISIÓN 3: BUSCAR UNA AMENAZA
    // Tiempo O(h): O(log n) si el árbol está balanceado; O(n) en el peor caso.
    public boolean buscar(int amenaza) {
        return buscarRecursivo(raiz, amenaza);
    }

    private boolean buscarRecursivo(NodoVengador actual, int amenaza) {
        if (actual == null) {
            return false;
        }
        if (actual.valor == amenaza) {
            return true;
        }
        if (amenaza < actual.valor) {
            return buscarRecursivo(actual.izquierdo, amenaza);
        }
        return buscarRecursivo(actual.derecho, amenaza);
    }

    // MISIÓN 4: RECORRIDO INORDEN: IZQUIERDA - RAÍZ - DERECHA
    public void inOrden() {
        inOrdenRecursivo(raiz);
    }

    private void inOrdenRecursivo(NodoVengador actual) {
        if (actual != null) {
            inOrdenRecursivo(actual.izquierdo);
            System.out.print(actual.valor + " ");
            inOrdenRecursivo(actual.derecho);
        }
    }

    // MISIÓN 5: RECORRIDO PREORDEN: RAÍZ - IZQUIERDA - DERECHA
    public void preOrden() {
        preOrdenRecursivo(raiz);
    }

    private void preOrdenRecursivo(NodoVengador actual) {
        if (actual != null) {
            System.out.print(actual.valor + " ");
            preOrdenRecursivo(actual.izquierdo);
            preOrdenRecursivo(actual.derecho);
        }
    }

    // MISIÓN 6: RECORRIDO POSTORDEN: IZQUIERDA - DERECHA - RAÍZ
    public void postOrden() {
        postOrdenRecursivo(raiz);
    }

    private void postOrdenRecursivo(NodoVengador actual) {
        if (actual != null) {
            postOrdenRecursivo(actual.izquierdo);
            postOrdenRecursivo(actual.derecho);
            System.out.print(actual.valor + " ");
        }
    }

    // MISIÓN 6: VACIAR EL ÁRBOL EN POSTORDEN
    // Desconecta las referencias; Java recupera la memoria cuando los nodos
    // dejan de ser alcanzables, mediante su recolector de basura.
    public void vaciar() {
        raiz = vaciarRecursivo(raiz);
    }

    private NodoVengador vaciarRecursivo(NodoVengador actual) {
        if (actual == null) {
            return null;
        }
        actual.izquierdo = vaciarRecursivo(actual.izquierdo);
        actual.derecho = vaciarRecursivo(actual.derecho);
        return null;
    }

    // MISIÓN 7: CONTAR TODOS LOS NODOS
    public int contarLineas() {
        return contarRecursivo(raiz);
    }

    private int contarRecursivo(NodoVengador actual) {
        if (actual == null) {
            return 0;
        }
        return 1 + contarRecursivo(actual.izquierdo)
                + contarRecursivo(actual.derecho);
    }

    // MISIÓN 8: ENCONTRAR EL MENOR
    public int encontrarMenor() {
        if (raiz == null) {
            throw new IllegalStateException("El árbol está vacío");
        }

        NodoVengador actual = raiz;
        while (actual.izquierdo != null) {
            actual = actual.izquierdo;
        }
        return actual.valor;
    }

    // MISIÓN 8: ENCONTRAR EL MAYOR
    public int encontrarMayor() {
        if (raiz == null) {
            throw new IllegalStateException("El árbol está vacío");
        }

        NodoVengador actual = raiz;
        while (actual.derecho != null) {
            actual = actual.derecho;
        }
        return actual.valor;
    }

    // MISIÓN 9: CALCULAR LA ALTURA
    // La altura es la distancia en aristas desde la raíz hasta la hoja más lejana.
    // Una hoja tiene altura 0; por convenio, un árbol vacío tiene altura -1.
    public int calcularAltura() {
        return alturaRecursiva(raiz);
    }

    private int alturaRecursiva(NodoVengador actual) {
        if (actual == null) {
            return -1;
        }

        int alturaIzquierda = alturaRecursiva(actual.izquierdo);
        int alturaDerecha = alturaRecursiva(actual.derecho);

        return 1 + Math.max(alturaIzquierda, alturaDerecha);
    }

    // MISIÓN 10: ELIMINAR UN NODO
    public void eliminar(int valor) {
        raiz = eliminarRecursivo(raiz, valor);
    }

    private NodoVengador eliminarRecursivo(NodoVengador actual, int valor) {
        if (actual == null) {
            return null;
        }

        if (valor < actual.valor) {
            actual.izquierdo = eliminarRecursivo(actual.izquierdo, valor);
        } else if (valor > actual.valor) {
            actual.derecho = eliminarRecursivo(actual.derecho, valor);
        } else {
            // CASO 1: nodo sin hijos (hoja)
            if (actual.izquierdo == null && actual.derecho == null) {
                return null;
            }

            // CASO 2: nodo con un solo hijo
            if (actual.izquierdo == null) {
                return actual.derecho;
            }
            if (actual.derecho == null) {
                return actual.izquierdo;
            }

            // CASO 3: nodo con dos hijos: sucesor inorden
            NodoVengador sucesor = encontrarSucesor(actual.derecho);
            actual.valor = sucesor.valor;
            actual.nombre = sucesor.nombre;
            actual.derecho = eliminarRecursivo(actual.derecho, sucesor.valor);
        }

        return actual;
    }

    private NodoVengador encontrarSucesor(NodoVengador actual) {
        while (actual.izquierdo != null) {
            actual = actual.izquierdo;
        }
        return actual;
    }
}
