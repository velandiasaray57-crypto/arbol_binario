# Revisión de las 10 misiones

Se revisaron `ArbolBinario.java`, `NodoVengador.java` y `Main.java` del ZIP original.

## Resultado por ejercicio

| Misión | Evaluación del original | Resultado de la revisión |
| --- | --- | --- |
| 1. Yggdrasil | Correcta. | Enlaza manualmente Asgard con Midgard a la izquierda y Vanaheim a la derecha. El ejercicio pide estos tres nodos, aunque la ambientación mencione nueve reinos. |
| 2. Inserción BST | Correcta. | Inserción recursiva, con actualización de la raíz y de los enlaces. Los valores repetidos se ignoran; el enunciado no exige almacenarlos. |
| 3. Búsqueda | Correcta. | Devuelve `true` o `false`, incluida la búsqueda en un árbol vacío. Su tiempo es O(h), siendo h la altura: O(log n) si está balanceado y O(n) en el peor caso. Un BST simple no garantiza O(log n). Se añadió esta precisión como comentario. |
| 4. InOrden | Correcta. | Visita izquierda, raíz y derecha; imprime los valores de menor a mayor. |
| 5. PreOrden | Correcta. | Visita raíz, izquierda y derecha. El ejercicio pide el recorrido, no implementar una clonación completa. |
| 6. PostOrden | Recorrido correcto; el original solo imprime. | Visita izquierda, derecha y raíz. Se añadió `vaciar()` para cubrir también la destrucción descrita: desconecta los enlaces en postorden y deja la raíz en `null`. `Main` lo demuestra con un árbol auxiliar. |
| 7. Contar líneas | Correcta. | Cuenta todos los nodos y devuelve 0 si el árbol está vacío. |
| 8. Menor y mayor | Correcta. | Recorre el extremo izquierdo o derecho del BST. En un árbol vacío lanza `IllegalStateException`, una forma válida de indicar que no existe un extremo. |
| 9. Altura | Requería ajuste según la distancia solicitada. | El original contaba nodos. Ahora cuenta aristas: una hoja tiene altura 0, el árbol del ejemplo tiene altura 3 y el árbol vacío tiene altura -1 por convenio. |
| 10. Eliminar | Correcta. | Resuelve hoja, un hijo y dos hijos; actualiza la raíz y usa el sucesor inorden. Copia tanto el valor como el nombre y conserva los hijos del sucesor. |

## Referencias y memoria

En Java se manejan referencias a objetos, no punteros explícitos ni liberación manual con `free` o `delete`. `vaciar()` elimina las referencias del árbol en postorden. Los nodos quedan disponibles para el recolector de basura cuando ninguna otra referencia los mantiene alcanzables; la recuperación no tiene que ocurrir inmediatamente.

`postOrden()` conserva su función de recorrido e impresión. `vaciar()` realiza el vaciado. Así pueden demostrarse ambas operaciones y continuar después con las demás misiones.

## Restricción de librerías

La solución no utiliza el Java Collection Framework: no hay `ArrayList`, `List`, `LinkedList`, `Stack`, `Queue`, `Map`, `Set` ni estructuras automáticas equivalentes. Los nodos están enlazados mediante `izquierdo` y `derecho`. El arreglo `int[]` de `Main` es un arreglo nativo, no una colección.

Las pruebas usan únicamente `java.io.ByteArrayOutputStream` y `java.io.PrintStream` para verificar lo que imprimen los recorridos. No son colecciones ni se usan para implementar el árbol.

## Validación realizada

- Compilación dirigida a Java 8 con codificación UTF-8 y comprobación de advertencias.
- Ejecución de `Main` en Java 8.
- 84 comprobaciones automáticas, todas satisfactorias: estructura y nombres de Yggdrasil, inserciones, duplicados, búsquedas, los tres recorridos, vaciado en postorden, conteo, extremos, alturas y eliminación.
- Se probaron árboles vacíos, una hoja, árboles lineales, enteros negativos y extremos, eliminación de la raíz, nodos internos, valores ausentes y sucesores con hijo derecho.

Con los valores de `Main`, antes de eliminar nodos:

```text
InOrden:   10 20 30 40 50 60 70 80 90
PreOrden:  50 40 20 10 30 60 80 70 90
PostOrden: 10 30 20 40 70 90 80 60 50
Cantidad: 9
Menor: 10
Mayor: 90
Altura en aristas: 3
```

## Ejecutar desde una terminal con un JDK en PATH

Abrir una terminal en la carpeta extraída y ejecutar:

```text
javac -encoding UTF-8 -d build ArbolBinario.java NodoVengador.java Main.java pruebas/PruebasArbolBinario.java
java -cp build Main
java -cp build PruebasArbolBinario
```

En NetBeans, agregar las tres clases principales al mismo paquete, manteniendo una declaración `package` idéntica en las tres si el proyecto usa paquetes. La clase de pruebas es opcional y debe usar ese mismo paquete si se incorpora al proyecto.
