public class NodoVengador {

    int valor;
    String nombre;

    NodoVengador izquierdo;
    NodoVengador derecho;

    public NodoVengador(int valor) {
        this.valor = valor;
        this.nombre = String.valueOf(valor);
        this.izquierdo = null;
        this.derecho = null;
    }

    public NodoVengador(int valor, String nombre) {
        this.valor = valor;
        this.nombre = nombre;
        this.izquierdo = null;
        this.derecho = null;
    }
}
